CREATE TABLE IF NOT EXISTS userreviews(
    id BIGINT NOT NULL PRIMARY KEY, 
    review_date DATE, 
    tv_show VARCHAR(2000), 
    review VARCHAR(2000)
    );