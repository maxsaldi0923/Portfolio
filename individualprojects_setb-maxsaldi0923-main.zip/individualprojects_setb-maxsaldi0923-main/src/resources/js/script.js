

function checkValid() {
    /* Note that you do NOT have to do a document.getElementById anywhere in this exercise. Use the elements below */
    var Name = document.getElementById("showName").value;
    var Num = document.getElementById("ratingVal").value;
        if(Num != '')
        {
            if(Num >= 0 && Num <= 10)
            {
                document.getElementById("ObjRev").submit();
                console.log("correct");
            }
            else
            {
                document.getElementById("my_submit_button").innerHTML = "Submit (Rating must be in 0-10)";
            }
        }
        else
        {
            document.getElementById("my_submit_button").innerHTML = "Submit (Rating cant be null)";
        }
    }