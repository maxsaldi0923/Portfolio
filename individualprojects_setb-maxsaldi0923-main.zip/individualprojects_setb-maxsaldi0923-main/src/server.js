// Load the modules
var express = require('express'); //Ensure our express framework has been added
var app = express();
var bodyParser = require('body-parser'); //Ensure our body-parser tool has been added
const path = require("path");

app.use(bodyParser.json());              // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies\

const axios = require('axios');
var pgp = require('pg-promise')();

const dev_dbConfig = {
	host: 'db',
	port: 5432,
	database: process.env.POSTGRES_DB,
	user:  process.env.POSTGRES_USER,
	password: process.env.POSTGRES_PASSWORD
};

const isProduction = process.env.NODE_ENV === 'production';
const dbConfig = isProduction ? process.env.DATABASE_URL : dev_dbConfig;

if (isProduction) {
	pgp.pg.defaults.ssl = {rejectUnauthorized: false};
}

var db = pgp(dbConfig);

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(express.static(__dirname + '/'));//This line is necessary for us to use relative paths and access our resources directory


/*
var express = require('express'); //Express - a web application framework that provides useful utility functions like 'http'
var app = express();
var bodyParser = require('body-parser'); // Body-parser -- a library that provides functions for parsing incoming requests
app.use(bodyParser.json()); // Support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // Support encoded bodies
const axios = require('axios');
const qs = require('query-string');
const { get } = require('got');
const e = require('express');

// Set the view engine to ejs
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/'));// Set the relative path; makes accessing the resource directory easier

var pgp = require('pg-promise')();

const dev_dbConfig = {
  host: 'ec2-18-210-159-154.compute-1.amazonaws.com',
  port: 5432,
  database: process.env.POSTGRES_DB,
  user:  process.env.POSTGRES_USER,
  password: process.env.POSTGRES_PASSWORD
};

const isProduction = process.env.NODE_ENV === 'production';
const dbConfig = isProduction ? process.env.DATABASE_URL : dev_dbConfig;

if (isProduction) {
  pgp.pg.defaults.ssl = {rejectUnauthorized: false};
}

var db = pgp(dev_dbConfig);


*/
// Home page - DON'T CHANGE
app.get('/', function(req, res) {
  res.render('pages/main', {
    my_title: "Home Page",
    items: '',
    error: false,
    message: 'Bad error please retry',
  });
});
app.get('/reviews', function(req, res) {
  var review_list = "SELECT * FROM userreviews";
  db.task('get-everything', task => {
      return task.batch([
          task.any(review_list)
      ]);
    })
    .then(list => {
      res.render('pages/reviews', {
        my_title: "Reviews page",
        items: list[0],
        error: false,
        message: '',
      });
      
    })
    .catch(error => {
      console.log(error);
      res.render('pages/main',{
        my_title: "show",
        items: '',
        error: true,
        message: error,
      })
    });
});
app.post('/reviews', function(req, res) {
  var review_list = "SELECT * FROM userreviews WHERE tv_show ='"+ req.body.filter +"'";
  var review_list2 = "SELECT * FROM userreviews";
  
  db.task('/get-everything', task => {
      return task.batch([
          task.any(review_list),
          task.any(review_list2)
      ]);
    })
    .then(list => {
      if(list[0].length != 0)
      {
        var pass = list[0]
      }
      else
      {
        var pass = list[1]
      }
      
      res.render('pages/reviews', {
        my_title: "Reviews page",
        items: pass,
        error: false,
        message: '',
      });
      
    })
    .catch(error => {
      console.log(error);
      res.render('pages/main',{
        my_title: "show",
        items: '',
        error: true,
        message: error,
      })
    });
});


//to request data from API for given search criteria
//TODO: You need to edit the code for this route to search for movie reviews and return them to the front-end
app.post('/get_feed', function(req, res) {
  //console.log("request parameters: ", req);
    var title = req.body.title; //TODO: Remove null and fetch the param (e.g, req.body.param_name); Check the NYTimes_home.ejs file or console.log("request parameters: ", req) to determine the parameter names
    if(title) {
      axios({
          url: `https://api.tvmaze.com/search/shows?q=${title}`,
          method: 'GET',
          dataType:'json',
        })
          .then(items => {
            profile = items.data[0].show.image;
            rating = items.data[0].score
            show_name = items.data[0].show.name
            res.render('pages/main',{
              my_title: "Shows",
              items: items,
              error: false,
              message: '',
            })
            
          })
          .catch(error => {
            console.log(error);
            res.render('pages/main',{
              my_title: "show",
              items: '',
              error: true,
              message: "That show doesent exist",
            })
          });
      }
});
app.post('/add_review', function(req, res) {
  today = new Date().toISOString().slice(0, 10)
  showName = req.body.showName;
  reviewV = req.body.ratingV;
  reviewT = req.body.reviewT;
  rev = "Rating: " + reviewV + "\nReview: " + reviewT;
  let val = (((rev.length * reviewV) - showName.length) + 2 * (rev.length*rev.length - reviewV));
  var add = "INSERT INTO userreviews(id, review_date, tv_show, review) VALUES ('"+val+"','"+today+"','"+showName+"','"+rev+"') ON CONFLICT DO NOTHING";
  var review_list2 = "SELECT * FROM userreviews";
  db.task('get-everything', task => {
    return task.batch([
        task.any(add),
        task.any(review_list2)
    ]);
  })
  
  .then(items => {
    res.render('pages/reviews',{
      my_title: "Reviews page",
      items: items[1],
      error: false,
      message: '',
    })
  })
  .catch(error => {
    console.log(error);
    res.render('pages/main',{
      my_title: "show",
      items: '',
      error: true,
      message: error,
    })
  });

});


const server = app.listen(process.env.PORT || 3000, () => {
  console.log(`Express running → PORT ${server.address().port}`);
});