<?php
    require "header.php";
?>

<main>
    <div class="errorcontainer">
        <h2 class="error-message">Error 404</h2>
        <h4 class="error-detail">Page could not be found!<br>Please use the navigation bar above.</h4>
        <div class="imgcontainer">
        </div>
    </div>
</main>

<?php
    require "footer.php";
?>